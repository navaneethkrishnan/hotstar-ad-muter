(async()=>{
const pad=document.getElementById("pad"),val=document.getElementById("val");
const x=await chrome.storage.local.get({endPadMs:0,leadMs:1000});
pad.value=(x.leadMs??1000)/1000;val.textContent=(+pad.value).toFixed(1);
pad.oninput=()=>val.textContent=(+pad.value).toFixed(1);
document.getElementById("save").onclick=async()=>{
 await chrome.storage.local.set({leadMs:Math.round(+pad.value*1000)});
 document.getElementById("save").textContent="Saved ✓";
 setTimeout(()=>document.getElementById("save").textContent="Save setting",1200);
};
})();