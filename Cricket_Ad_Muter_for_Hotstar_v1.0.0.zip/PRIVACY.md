# Privacy Policy — Cricket Ad Muter for Hotstar

Cricket Ad Muter for Hotstar does not collect, sell, transmit, or share
personal information, browsing history, account information, or page content.

The extension observes only the Hotstar network event needed to detect an
advertisement slot and uses Chrome's tab mute control. User settings are
stored locally in Chrome extension storage.

No analytics, advertising, remote code, external tracking, or user accounts
are used.

Contact: the developer account associated with this Chrome Web Store item.
